# Arbitrage System
An AI-driven automated arbitrage system using FastAPI, Python, and Vercel.

## Setup
1. Run `python setup_project.py`
2. Open in VS Code and install extensions.
3. Deploy to Vercel using `vercel deploy`.